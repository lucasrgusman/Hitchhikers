package com.example.gatorrider;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import android.content.Intent;

public class AvailRides extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        Intent i = getIntent();
        String origin = i.getStringExtra("origin");
        String destination = i.getStringExtra("dest");
        String date = i.getStringExtra("date");
        String seats = i.getStringExtra("seats");
        String price = i.getStringExtra("price");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avail_rides);

        ArrayList<Ride> availRides = Ride.findRide(origin, destination, seats, price, date);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(availRides,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
