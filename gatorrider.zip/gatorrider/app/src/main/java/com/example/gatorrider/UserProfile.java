package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;

public class UserProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        TextView name = (TextView) findViewById(R.id.name);
        name.setText("Name: " + user.getName());

        TextView age = (TextView) findViewById(R.id.age);
        age.setText("Age: " + user.getPhone());

        TextView gender = (TextView) findViewById(R.id.gender);
        name.setText(user.getGender());

        Button home = findViewById(R.id.home);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserProfile.this, Home.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });


    }
}
