package com.example.gatorrider;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
public class Person implements Parcelable {

        public  Person (Parcel in) {
            String[] data = new String[6];
            in.readStringArray(data);
            // the order needs to be the same as in writeToParcel() method
            this.name = data[0];
            this.phone = data[1];
            this.gender = data[2];
            this.email = data[3];
            this.userName = data[4];
            this.password = data[5];

        }

    public int describeContents(){
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[] {
                this.name,
                this.phone,
                this.gender,
                this.email,
                this.userName,
                this.password});
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Person createFromParcel(Parcel in) {
            return new Person(in);
        }

        public Person[] newArray(int size) {
            return new Person[size];
        }
    };


    Scanner scnr = new Scanner(System.in);
    private String name;
    private String phone;
    private String gender;
    private String email;
    private String userName;
    private String password;
    final String[] locations = {"Gainesville" , "Ocala", "Orlando", "Jacksonville", "Sarasota", "Miami", "Tallahassee"};

    public Person ( String _fullname, String _phone, String _gender, String _email, String _userName, String _password) {
        name = _fullname;
        phone = _phone;
        gender = _gender;
        email = _email;
        userName = _userName;
        password = _password;
    }

    public void setName (String newName) {
        name = newName;
    }

    public String getName () {
        return name;
    }

    public void setPhone (String _phone) {
        phone = _phone;
    }

    public String getPhone () {
        return phone;
    }

    public void setGender (String _gender) {
        gender = _gender;
    }

    public String getGender () {
        return gender;
    }

    public void setEmail (String newEmail) {
        email = newEmail;
    }

    public String getEmail () {
        return email;
    }

    public void setUserName (String newUserName) {
        userName = newUserName;
    }
    public String getUserName() {
        return userName;
    }

    public void setPassword (String newPassword) {
        password = newPassword;
    }

    public String getPassword () {
        return password;
    }







}
