package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Button;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView name = (TextView) findViewById(R.id.name);
        name.setText(user.getName());

        //TextView gender = (TextView) findViewById(R.id.gender);
        //gender.setText("Gender: " + user.getGender());

        TextView phone = (TextView) findViewById(R.id.phone);
        phone.setText(user.getPhone());


        TextView userName = (TextView) findViewById(R.id.username);
        userName.setText(user.getUserName());

        TextView email = (TextView) findViewById(R.id.email);
        email.setText(user.getEmail());

        Button back = findViewById(R.id.home);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, Home.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });

        /*Button changepw = findViewById(R.id.changepw);
        changepw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, Changepw.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });*/

        ImageButton edit = findViewById(R.id.edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, EditProfile.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });


    }
}
