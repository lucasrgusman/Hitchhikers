package com.example.gatorrider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class EditProfile extends AppCompatActivity {

    String fullName;
    String gender;
    String userPhone;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Person user = (Person) getIntent().getParcelableExtra("user_data");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);



        final EditText _firstname;
        final CheckBox _male, _female;
        final EditText _phone;
        final EditText _email;


        _firstname =  findViewById(R.id.name);
        _phone = findViewById(R.id.phone);
        _email = findViewById(R.id.email);
        _male = findViewById(R.id.male);
        _female = findViewById(R.id.female);

        _male.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (_male.isChecked()) {
                    user.setGender("male");
                } else {
                   user.setGender("female");
                }

            }

        });

        _female.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (_female.isChecked()) {
                    user.setGender("female");
                }
            }

        });



        Button done = findViewById(R.id.done);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fullName = _firstname.getText().toString();
                userPhone = _phone.getText().toString();
                email = _email.getText().toString();

                user.setName(fullName);
                user.setPhone(userPhone);
                user.setEmail(email);

                Intent intent = new Intent(EditProfile.this, Profile.class);
                intent.putExtra("user_data", user);
                startActivity(intent);
            }

        });



    }
}
